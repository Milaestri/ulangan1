<!doctype html>
<html lang="en">

<head>
  <title>Hello, world!</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
</head>

<body class="dark-edition">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="black" data-image="./assets/img/sidebar-2.jpg">
      <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          Creative Tim
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item"         >
            <a class="nav-link" href="./template.html">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>

           <li class="nav-item active"  >
            <a class="nav-link" href="./user.php">
              <i class="material-icons">person</i>
              <p>Contact</p>
            </a>
          </li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:void(0)">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="javascript:void(0)">
                  <i class="material-icons">notifications</i>
                  <p class="d-lg-none d-md-block">
                    Notifications
                  </p>
                </a>
              </li>
              <!-- your navbar here -->
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->

          <a href="inputdata.php" class="btn btn-primary">Input Data</a>

  <div class="card-body">
        
        <table id="example1" class="table table-responsive-x1 table-hover display">
      
      <thead>
        
        <tr>
          
          <th>id</th>

          <th>nama</th>

          <th>email</th>

          <th>no_telp</th>

          <th>pekerjaan</th>

          <th>aksi</th>

        </tr>

      </thead>

      <tbody>
        
<?php       

  include 'koneksi.php';

    $no = 1;

    $number = mysqli_query($dbconnect, "SELECT * FROM namacontact");



    while ($query = mysqli_fetch_assoc($number)) {


?>
  <form  action="prosesinputbarang.php" method="post">
    
       <tr>
        
         <td><?php echo $no++;  ?></td>

        <td><?php echo $query ['nama']  ?></td>

         <td><?php echo $query ['email'] ?></td>

         <td><?php echo $query ['no_telp']  ?></td>

         <td><?php echo $query ['pekerjaan']  ?></td>

         <td>
          
          <a href="updatedata.php?id=<?php echo $query ['id']?>" class="btn btn-primary">Edit</a>

          <a href="proseshapusdata.php?id=<?php echo $query ['id']?>" class="btn btn-danger" onclick="return confirm ('Apa anda yakin ingin menghapus data anda?  dengan id <?php echo $query ['id']?>??')">Hapus</a>
         </td>
       </tr>

  </form>

<?php   }   ?>

        </tbody>
      </div>
    </div>
  </main>
  </div>
  </div>
    


    

  
    <script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
    <footer>
            <div class="container">
        <small><center>Copyright &copy; 2022 - Mila/15/XI RPL2</center></small>        
            </div>
        </footer>
  </body>
 </html>


        